public class Producto {
    private double precio;
    private String descripcion;

    public Producto(double precio) {
        this.precio = precio;
    }
}
