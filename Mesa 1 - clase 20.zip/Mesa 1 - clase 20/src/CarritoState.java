public interface CarritoState {
    CarritoState agregarProducto();
    CarritoState cancelarCarrito();
}
