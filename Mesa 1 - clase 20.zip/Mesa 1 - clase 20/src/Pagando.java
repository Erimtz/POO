public class Pagando implements CarritoState {
    @Override
    public CarritoState agregarProducto() {
        return null;
    }

    @Override
    public CarritoState cancelarCarrito() {
        return null;
    }

}
