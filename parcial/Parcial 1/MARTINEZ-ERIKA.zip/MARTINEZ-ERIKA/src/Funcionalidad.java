
public interface Funcionalidad {

    boolean puedeDisparar200();
}
