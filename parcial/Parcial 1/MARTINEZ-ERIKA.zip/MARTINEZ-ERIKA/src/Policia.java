public class Policia {
    private String nombre;
    private String apellido;
    private String legajo;

    public Policia(String nombre, String apellido, String legajo) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.legajo = legajo;
    }
}
