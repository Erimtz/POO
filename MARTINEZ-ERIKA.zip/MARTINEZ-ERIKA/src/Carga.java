public abstract class Carga {
    private String nombre;
    private double pesoCarga;

    public abstract double calcularPeso();

}
